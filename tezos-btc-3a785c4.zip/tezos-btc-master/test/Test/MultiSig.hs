{- SPDX-FileCopyrightText: 2019 Bitcoin Suisse
 -
 - SPDX-License-Identifier: LicenseRef-Proprietary
 -}
module Test.MultiSig (test_multisig) where

import qualified Data.Set as Set
import qualified Data.Text as T (drop)
import Test.Hspec (Expectation)
import Test.HUnit (assertBool, assertEqual)
import Test.Tasty (TestTree, testGroup)
import Test.Tasty.HUnit (testCase)

import Lorentz hiding (SomeContract)
import Lorentz.Contracts.ManagedLedger.Test (OriginationParams(..))
import Lorentz.Contracts.Multisig
import Lorentz.Contracts.TZBTC as TZBTC
import qualified Lorentz.Contracts.TZBTC.Types as TZBTCTypes (SafeParameter(..))
import Lorentz.Test.Integrational
import Test.TZBTC (checkField, originateTzbtcV1ContractRaw)
import Text.Hex (decodeHex)
import Tezos.Address
import Tezos.Crypto
import qualified Tezos.Crypto.Ed25519 as Ed25519
import Util.MultiSig as MSig
import Util.Named

{-# ANN module ("HLint: ignore Reduce duplication" :: Text) #-}

addSignature_ :: ByteString -> (PublicKey, Signature) -> Either String Package
addSignature_ e (pk, sig) = do
  f <- decodePackage e :: Either String Package
  addSignature f (pk, sig)

withMultiSigContract_
  :: Natural
  -> Natural
  -> [PublicKey]
  -> (TAddress MSigParameter -> IntegrationalScenario)
  -> Expectation
withMultiSigContract_ counter thresh pkList callback =
  integrationalTestExpectation $ do
    msig <- lOriginate (tzbtcMultisigContract @'CustomErrors) "Multisig Contract"
      (mkStorage counter thresh pkList) (toMutez 0)
    callback (toTAddress msig)

withMultiSigContract
  :: Natural
  -> Natural
  -> [PublicKey]
  -> (TAddress MSigParameter -> IntegrationalScenario)
  -> Expectation
withMultiSigContract counter threshold masterPKList =
  withMultiSigContract_
    counter threshold masterPKList

sign_ :: Ed25519.SecretKey -> Text -> Signature
sign_ sk bs = case decodeHex (T.drop 2 bs) of
  Just dbs -> SignatureEd25519 $ Ed25519.sign sk dbs
  Nothing -> error "Error with making signatures"

originateTzbtc
  :: TAddress MSigParameter
  -> IntegrationalScenarioM (TAddress (TZBTC.Parameter SomeTZBTCVersion))
originateTzbtc msig =
  originateTzbtcV1ContractRaw genesisAddress3 $ OriginationParams
    { opAdmin = toAddress msig
    , opBalances = mempty
    }

test_multisig :: TestTree
test_multisig = testGroup "TZBTC contract multi-sig functionality test"
  [ testCase "Test call to multisig to add an operator by owner works" $ do
      -- Originate multisig with threshold 2 and a master pk list of
      -- three public keys
      withMultiSigContract 0 2 masterPKList $ \msig -> do
        -- Define initial storage for main contract and expected storage
        -- after the call
        tzbtc <- originateTzbtc msig
        -- Make the multi-sig call that adds an operator
        let
          tzbtcParam = TZBTCTypes.AddOperator (#operator .! operatorAddress)
          package = MSig.mkPackage msig 0 tzbtc tzbtcParam
          bytesToSign = getBytesToSign package
          encodedPackage = MSig.encodePackage package
          -- Signing the bytes
          alicePackage = fromRight_ "Adding signature failed" $
            addSignature_ encodedPackage
            (alicePK, sign_ aliceSK bytesToSign)
          carlosPackage = fromRight_ "Adding signature failed" $
            addSignature_ encodedPackage
            (carlosPK, sign_ carlosSK bytesToSign)
          --Make multisig param
          (msaddr, mparam) = fromRight_ "Making multisig parameter failed" $
            MSig.mkMultiSigParam masterPKList ((alicePackage) :| [carlosPackage])
        -- Finally call the multisig contract
        lCallEP msaddr (Call @"MainParameter") mparam
        validate . Right $
          lExpectStorageUpdate tzbtc
            (checkField operators
              (Set.member operatorAddress) "New operator not found")

  , testCase "Test call to multisig to add an operator by fails with one signature less" $ do
      -- Originate multisig with threshold 2 and a master pk list of
      -- three public keys
      withMultiSigContract 0 2 masterPKList $ \msig -> do
        -- Originate main contract with owner set to multisig
        tzbtc <- originateTzbtc msig
        -- Make the multi-sig call that adds an operator
        let
          tzbtcParam = TZBTCTypes.AddOperator (#operator .! operatorAddress)
          package = MSig.mkPackage msig 0 tzbtc tzbtcParam
          bytesToSign = getBytesToSign package
          encodedPackage = MSig.encodePackage package
          -- Signing the bytes
          alicePackage = fromRight_ "Adding signature failed" $
            addSignature_ encodedPackage
            (alicePK, sign_ aliceSK bytesToSign)
          --Make multisig param. We use only one signature instead of
          --the require threshold of two signatures.
          (_, mparam) = fromRight_ "Making multisig parameter failed" $
            MSig.mkMultiSigParam masterPKList ((alicePackage) :| [])
        -- Finally call the multisig contract
        lCallEP msig (Call @"MainParameter") mparam
        validate . Left $
          lExpectMichelsonFailed (const True) msig
  , testCase "Test call to multisig to add an operator by fails for bad signatures" $ do
      -- Originate multisig with threshold 2 and a master pk list of
      -- three public keys
      withMultiSigContract 0 2 masterPKList $ \msig -> do
        -- Originate main contract with owner set to multisig
        tzbtc <- originateTzbtc msig
        -- Make the multi-sig call that adds an operator
        let
          tzbtcParam = TZBTCTypes.AddOperator (#operator .! operatorAddress)
          package = MSig.mkPackage msig 0 tzbtc tzbtcParam
          bytesToSign = getBytesToSign package
          encodedPackage = MSig.encodePackage package
          -- Signing the bytes
          alicePackage = fromRight_ "Adding signature failed" $
            -- Make a bad signature. Use Alice's public key but Bob's secret.
            addSignature_ encodedPackage
            (alicePK, sign_ bobSK bytesToSign)
          carlosPackage = fromRight_ "Adding signature failed" $
            addSignature_ encodedPackage
            (carlosPK, sign_ carlosSK bytesToSign)
          --Make multisig param
          (msaddr, mparam) = fromRight_ "Making multisig parameter failed" $
            MSig.mkMultiSigParam masterPKList ((alicePackage) :| [carlosPackage])
        -- Finally call the multisig contract
        lCallEP msaddr (Call @"MainParameter") mparam
        validate . Left $
          lExpectMichelsonFailed (const True) msig
  , testCase "Test replay attack prevention counter" $ do
      -- Originate multisig with threshold 2 and a master pk list of
      -- three public keys
      withMultiSigContract 0 2 masterPKList $ \msig -> do
        -- Originate main contract with owner set to multisig
        tzbtc <- originateTzbtc msig
        -- Make the multi-sig call that adds an operator
        let
          tzbtcParam = TZBTCTypes.AddOperator (#operator .! operatorAddress)
          package = MSig.mkPackage msig 0 tzbtc tzbtcParam
          bytesToSign = getBytesToSign package
          encodedPackage = MSig.encodePackage package
          -- Signing the bytes
          alicePackage = fromRight_ "Adding signature failed" $
            --Use Alice's public key but bob's secret.
            addSignature_ encodedPackage
            (alicePK, sign_ aliceSK bytesToSign)
          carlosPackage = fromRight_ "Adding signature failed" $
            addSignature_ encodedPackage
            (carlosPK, sign_ carlosSK bytesToSign)
          --Make multisig param
          (msaddr, mparam) = fromRight_ "Making multisig parameter failed" $
            MSig.mkMultiSigParam masterPKList ((alicePackage) :| [carlosPackage])
        -- Finally call the multisig contract
        lCallEP msaddr (Call @"MainParameter") mparam
        -- Now call again with the same param, this should fail.
        lCallEP msig (Call @"MainParameter") mparam
        validate . Left $
          lExpectMichelsonFailed (const True) msig
  , testCase "Test signed bundle created for one msig contract does not work on other" $ do
      -- Originate multisig with threshold 2 and a master pk list of
      -- three public keys
      withMultiSigContract 0 2 masterPKList $ \msig -> do
        -- Originate main contract with owner set to multisig
        --
        -- Make another multisig, after adding some nop seq to the front, so that
        -- the Integrational test will allow to originate it without complaining about
        -- the already originated one.
        mClone <- lOriginate (tzbtcMultisigContract @'CustomErrors) "Multisig Contract Clone"
          (mkStorage 0 2 masterPKList) (toMutez 1) -- Use a different initial balance
           -- so 'contract already originated' error is not triggered.
        tzbtc <- originateTzbtc msig
        -- Make the multi-sig call that adds an operator
        let
          tzbtcParam = TZBTCTypes.AddOperator (#operator .! operatorAddress)
          -- Here we make the multi-sig pacakge for msig address.
          -- But will call the cloned multi-sig using it.
          package = MSig.mkPackage msig 0 tzbtc tzbtcParam
          bytesToSign = getBytesToSign package
          encodedPackage = MSig.encodePackage package
          -- Signing the bytes
          alicePackage = fromRight_ "Adding signature failed" $
            --Use Alice's public key but bob's secret.
            addSignature_ encodedPackage
            (alicePK, sign_ aliceSK bytesToSign)
          carlosPackage = fromRight_ "Adding signature failed" $
            addSignature_ encodedPackage
            (carlosPK, sign_ carlosSK bytesToSign)
          --Make multisig param
          (msaddr, mparam) = fromRight_ "Making multisig parameter failed" $
            MSig.mkMultiSigParam masterPKList ((alicePackage) :| [carlosPackage])

        -- Call the actual contract with the bundle. Should work as
        -- expected.
        lCallEP msaddr (Call @"MainParameter") mparam
        validate . Right $
          lExpectStorageUpdate tzbtc
            (checkField operators
              (Set.member operatorAddress) "New operator not found")
                                                                --
        -- Call the clone with the bundle created for the real multisig
        -- contract.
        lCallEP mClone (Call @"MainParameter") mparam
        -- It should fail
        validate . Left $
          lExpectMichelsonFailed (const True) mClone

  , testCase "Test mkMultiSigParam function arranges the signatures in the order of public keys" $ do
      let
        msig  = TAddress @MSigParameter $
                unsafeParseAddress "KT19rTTBPeG1JAvrECgoQ8LJj1mJrN7gsdaH"
        tzbtc = TAddress @(TZBTC.Parameter SomeTZBTCVersion) $
                unsafeParseAddress "KT1XXJWcjrwfcPL4n3vjmwCBsvkazDt8scYY"

        tzbtcParam = TZBTCTypes.AddOperator (#operator .! operatorAddress)
        package = MSig.mkPackage @(TAddress MSigParameter) msig 0 tzbtc tzbtcParam
        bytesToSign = getBytesToSign package
        encodedPackage = MSig.encodePackage package
        -- Signing the bytes
        aliceSig = sign_ aliceSK bytesToSign
        carlosSig = sign_ carlosSK bytesToSign
        alicePackage = fromRight_ "Adding signature failed" $
          --Use Alice's public key but bob's secret.
          addSignature_ encodedPackage (alicePK, aliceSig)
        carlosPackage = fromRight_ "Adding signature failed" $
          addSignature_ encodedPackage (carlosPK, carlosSig)
        --Make multisig param, but extract the signature list
        mparam = fromRight_ "Making multisig parameter failed" $
          MSig.mkMultiSigParam masterPKList ((carlosPackage) :| [alicePackage])
      case mparam of
        (_, (_, sigList)) -> assertEqual
          "The signatures in multi-sig parameter is in the expected order"
          [Just aliceSig, Nothing, Just carlosSig]
          sigList
      let
        mparam_ = fromRight_ "Making multisig parameter failed" $
          MSig.mkMultiSigParam masterPKList ((alicePackage) :| [carlosPackage])
      case mparam_ of
        (_, (_, sigList)) -> assertEqual
          "The signatures in multi-sig parameter is in the expected order"
          [Just aliceSig, Nothing, Just carlosSig]
          sigList

  , testCase "Test user is not allowed to sign a bad package" $ do
      let
        msig  = TAddress @MSigParameter $
                unsafeParseAddress "KT19rTTBPeG1JAvrECgoQ8LJj1mJrN7gsdaH"
        tzbtc = TAddress @(TZBTC.Parameter SomeTZBTCVersion) $
                unsafeParseAddress "KT1XXJWcjrwfcPL4n3vjmwCBsvkazDt8scYY"

        tzbtcParam = TZBTCTypes.AddOperator (#operator .! operatorAddress)
        tzbtcParamBadParam = TZBTCTypes.RemoveOperator (#operator .! operatorAddress)
        package = MSig.mkPackage @(TAddress MSigParameter) msig 0 tzbtc tzbtcParam
        package2 = MSig.mkPackage @(TAddress MSigParameter) msig 0 tzbtc tzbtcParamBadParam

        -- replace operation with bad operation
        badPackage = package { pkToSign = pkToSign package2 } :: Package
        bytesToSign = getBytesToSign package
        aliceSig = sign_ aliceSK bytesToSign
      assertBool "User was able to sign bad package" (isLeft $ addSignature badPackage (alicePK, aliceSig))
  ]

  where
    fromRight_ er e = fromRight (error er) e
    operatorAddress :: Address
    operatorAddress = genesisAddress5

    aliceSK = Ed25519.detSecretKey "aa"
    bobSK = Ed25519.detSecretKey "bbb"
    carlosSK = Ed25519.detSecretKey "cccc"

    alicePK = PublicKeyEd25519 . Ed25519.toPublic $ aliceSK
    bobPK = PublicKeyEd25519 . Ed25519.toPublic $ bobSK
    carlosPK = PublicKeyEd25519 . Ed25519.toPublic $ carlosSK

    masterPKList = [alicePK, bobPK, carlosPK]
